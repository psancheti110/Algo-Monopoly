#include<iostream>

using namespace std;

#define M 100000007L

long long power(long long a, long long n)
{
  long long pow = 1;
  while (n)
  {
    //for (; p ; a=a*a %M, p >>= 1)
    if (n & 1)
    {
      pow *= a;
      pow %= M;
    }
    a = (a * a) % M;
    n >>= 1;
  }
  return pow;
}

int main()
{
  long long n;
  long long r1, r2, a, b, c, d, e, num, den;

  int test;
  cin >> test;

  while (test-- > 0)
  {
    cin >> n;

    a = power(3, n) % M;
    b = ((power(2, n) % M));
    num = ((a - (2 * b) % M + M) % M + 1 + M) % M;

    r1 = num * power(2, M - 2) % M;

    r1 %= M;

    c = (3 * b) % M;
    d = (3 * a) % M;
    e = (b * b) % M;
    num = ((e - d + M) % M + c - 1 + M) % M;
    r2 = num * power(2, M - 2) % M;

    r2 %= M;

    cout << r1 << " " << r2 << endl;
  }
  return 0;
}