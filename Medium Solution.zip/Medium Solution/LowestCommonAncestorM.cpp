#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<queue>
using namespace std;
#define ll __int64
#define INF 1000000000000000000
struct node
{
ll x,y,w,num;
}e[2005*2005];
struct node2
{
ll from;
ll to;
ll w;
ll next;
}ee[2005*3];
ll vis[20005];
ll head[200005];
ll a[2002][2002];
ll dist[2002][2002];
ll f[20005];
ll n;
ll cnt,cont;
ll cmp(node a,node b)
{
return a.w<b.w;
}
ll find(ll a)
{
ll r=a;
while(f[r]!=r)
r=f[r];
ll i=a;
ll j;
while(i!=r)
{
j=f[i];
f[i]=r;
i=j;
}
return r;
}
ll merge(ll a,ll b)
{
ll A,B;
A=find(a);
B=find(b);
if(A!=B)
{
f[B]=A;
}
}
void add(ll from,ll to,ll w)
{
ee[cont].to=to;
ee[cont].w=w;
ee[cont].next=head[from];
head[from]=cont++;
}
void Get_map()
{
cont=0;
memset(head,-1,sizeof(head));
for(ll i=1;i<=n;i++)f[i]=i;
sort(e,e+cnt,cmp);
for(ll i=0;i<cnt;i++)
{
if(find(e[i].x)!=find(e[i].y))
{
merge(e[i].x,e[i].y);
add(e[i].x,e[i].y,e[i].w);
add(e[i].y,e[i].x,e[i].w);
}
}
}
void SPFA(ll ss)
{
memset(vis,0,sizeof(vis));
for(ll i=1;i<=n;i++)dist[ss][i]=INF;
vis[ss]=1;
dist[ss][ss]=0;
queue<ll >s;
s.push(ss);
while(!s.empty())
{
ll u=s.front();
vis[u]=0;
s.pop();
for(ll i=head[u];i!=-1;i=ee[i].next)
{
ll v=ee[i].to;
ll w=ee[i].w;
if(dist[ss][v]>dist[ss][u]+w)
{
dist[ss][v]=dist[ss][u]+w;
if(vis[v]==0)
{
vis[v]=1;
s.push(v);
}
}
}
}
}
int main()
{
while(~scanf("%I64d",&n))
{
cnt=0;
for(ll i=1;i<=n;i++)
{
for(ll j=1;j<=n;j++)
{
scanf("%I64d",&a[i][j]);
if(j>i&&a[i][j]!=0)
{
e[cnt].num=(i-1)*n+j;
e[cnt].x=i;
e[cnt].y=j;
e[cnt++].w=a[i][j];
}
}
}
int flag=0;
Get_map();
for(ll i=1;i<=n;i++)SPFA(i);
for(ll i=1;i<=n;i++)
{
for(ll j=1;j<=n;j++)
{
if(dist[i][j]!=a[i][j])flag=1;
}
}
if(flag==0)printf("YES\n");
else printf("NO\n");
}
}
