#include<bits/stdc++.h>
using namespace std;
int etf(int n) {
    int res = n;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0)
            res = res - (res / i);
        while (n % i == 0)
            n /= i;
    }
    if (n != 1)
        res = res - (res / n);
    return res;
}
bool isPrime(int x) {
    if (x == 1)return false;
    for (int i = 2; i * i <= x; i++)
        if (x % i == 0)  return false;
    return true;
}
int main()
{
    int n, q;
    scanf("%d %d", &n, &q);
    int a[n], pref[n + 1];
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    pref[0] = 0;
    for (int i = 0; i < n; i++) {
        pref[i + 1] = pref[i];
        int x = etf(a[i]);
        if (isPrime(x)) pref[i + 1]++;
    }
    for (int i = 0; i < q; i++) {
        int l, r;
        scanf("%d %d", &l, &r);
        printf("%d\n", pref[r] - pref[l - 1]);
    }
}