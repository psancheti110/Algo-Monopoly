#include <bits/stdc++.h>
#define rf freopen("inp.in", "r", stdin)
#define MOD 1000000007
#define INF 1000000009
#define mbrc GoldMedalist16
#define pb push_back
#define mp make_pair
#define ll long long
#define RI(n) scanf("%d",&n)
#define RLL(n) scanf("%lld",&n)
#define PRI(n) printf("%d\n",n);
#define PRLL(n) printf("%lld\n",n);
#define NMAX 2000001
#define LN 20

using namespace std;

ll F[10000010];


ll countFact(ll n)
{
  ll k = 0;
  while (n >= MOD)
  {
    k += n / MOD;
    n /= MOD;
  }
  return k;
}

ll pow(ll base, ll exp) {
  base %= MOD;
  ll result = 1;
  while (exp > 0) {
    if (exp & 1) result = (result * base) % MOD;
    base = (base * base) % MOD;
    exp >>= 1;
  }
  return result;
}


ll InverseEuler(int n)
{
  return pow((ll)n, (ll)MOD - 2);
}

ll C(int n, int r)
{
  if (countFact(n) > countFact(r) + countFact(n - r))
    return 0;

  return (F[n] *
          ((InverseEuler(F[r]) *
            InverseEuler(F[n - r])) % MOD) % MOD);
}

int main() {
  F[0] = 1;
  for (int i = 1; i <= 10000000; i++) F[i] = (F[i - 1] * i) % MOD;

  int T; RI(T);

  while (T--) {
    ll N;
    ll K;
    RLL(N);
    RLL(K);
    ll ans = 0;
    ll ans1 = 1;
    ans1 = (ans1 * (K + N + 1)) % MOD;
    ans1 = (ans1 * C(K + N, N)) % MOD;
    ll ans2 = N + 1;
    ans2 = (ans2 * C(N + K + 1, K)) % MOD;
    ans2 -= (K * K) % MOD;
    while (ans2 < 0) ans2 += MOD;
    ans2 %= MOD;
    ans2 -= 3 * K + 2;
    while (ans2 < 0) ans2 += MOD;
    ans2 %= MOD;
    ans = ans1 + ans2;
    while (ans < 0) ans += MOD;
    ans %= MOD;
    ans = (ans * N) % MOD;
    ans = (ans * InverseEuler(((K + 1) * (K + 2)) % MOD)) % MOD;
    PRLL(ans);
  }
}