#include <bits/stdc++.h>

using namespace std;

typedef unsigned long long ll;

ll mgcd(ll a,ll b) {
	return b == 0 ? a : mgcd(b,a%b);
}

ll f[4];

int main() {
	ll n,m,q;
	ios::sync_with_stdio(0);
	cin >> n >> m >> q;
	ll t =mgcd(n,m);
	f[1] = n / t; f[2] = m / t;
	while(q--) {
		ll s1,s2,e1,e2;
		cin >> s1 >> s2 >> e1 >> e2;
		int t1 = s2 % f[s1] ? 1 : 0 , t2 = e2 % f[e1] ? 1 : 0; 
		if(s2  / f[s1] + t1 == e2 / f[e1] + t2) {
			cout << "YES" <<"\n";
		}
		else cout << "NO" <<"\n";
	}
	return 0;
}
