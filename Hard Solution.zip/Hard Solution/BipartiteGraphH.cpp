#include <bits/stdc++.h>

using namespace std;

const int N = 222;
const int AL = 26;

bool dp[N][AL][AL];
pair<pair<int, int>, int> p[N][AL][AL];

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);
#endif
	
	int n;
	string s;
	cin >> n >> s;
	dp[0][0][0] = 1;
	for (int i = 0; i < n; ++i) {
		int c = s[i] - 'a';
		for (int c1 = 0; c1 < AL; ++c1) {
			for (int c2 = 0; c2 < AL; ++c2) {
				if (!dp[i][c1][c2]) continue;
				if (c >= c1) {
					dp[i + 1][c][c2] = 1;
					p[i + 1][c][c2] = make_pair(make_pair(c1, c2), 0);
				}
				if (c >= c2) {
					dp[i + 1][c1][c] = 1;
					p[i + 1][c1][c] = make_pair(make_pair(c1, c2), 1);	
				}
			}
		}
	}
	
	int x = -1, y = -1;
	for (int c1 = 0; c1 < AL; ++c1) {
		for (int c2 = 0; c2 < AL; ++c2) {
			if (dp[n][c1][c2]) {
				x = c1, y = c2;
			}
		}
	}
	
	if (x == -1) {
		cout << "NO" << endl;
		return 0;
	}
	
	string res;
	for (int i = n; i > 0; --i) {
		int prvx = p[i][x][y].first.first;
		int prvy = p[i][x][y].first.second;
		if (p[i][x][y].second) res += '1';
		else res += '0';
		x = prvx;
		y = prvy;
	}
	
	reverse(res.begin(), res.end());
	cout << "YES" << endl << res << endl;
	
	return 0;
}
