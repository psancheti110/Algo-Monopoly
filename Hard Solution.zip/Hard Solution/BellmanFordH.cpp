#include <cstdio>
#include <cstring>
 
using namespace std;
 
const int INF = 0x3f3f3f3f;
 
int n,m,ans,st;
int g[15][15],d[15],f[1<<15];
 
int ckmin(int &a,int b){return b<a ? (a=b),1 : 0;}
int main()
{
	scanf("%d%d",&n,&m);
	memset(g,0x3f,sizeof(g));
	for(int i=0;i<n;i++) g[i][i]=0;
	for(int i=0;i<m;i++){
		int u,v,c;scanf("%d%d%d",&u,&v,&c);
		ans+=c;d[--u]++;d[--v]++;
		if(ckmin(g[u][v],c)) g[v][u]=c;
	}
	for(int k=0;k<n;k++)
		for(int i=0;i<n;i++)
			for(int j=0;j<n;j++)
				ckmin(g[i][j],g[i][k]+g[k][j]);
	st=0;
	for(int i=0;i<n;i++) if(d[i]){
		st|=(d[i]&1)<<i;
		if(g[0][i]==INF) return puts("-1"),0;
	}
	memset(f,0x3f,sizeof(f));
	f[st]=0;
	for(int i=st;i;i--) if(f[i]<INF)
		for(int j=0;j<n;j++) if(i&(1<<j))
			for(int k=j+1;k<n;k++) if(i&(1<<k))
				ckmin(f[i^(1<<j)^(1<<k)],f[i]+g[j][k]);
	printf("%d\n",f[0]+ans);
	return 0;
}
