
#include<cstdio>
#include<algorithm>
using namespace std;
const int N = 2e5 + 1;
int i, n, b[N];
double L = -2e4, R, x1, x2, f, g, t, a[N];
double F(double x)
{
	for (i = 0; i++ < n; a[i] = b[i] - x);
	for (t = f = g = i = 0; i++ < n; t = max(t, max(-f, g)))
		f = min(f + a[i], a[i]), g = max(g + a[i], a[i]);
	return t;
}
int main()
{
	for (scanf("%d", &n); i++ < n; scanf("%d", b + i));
	for (R = -L; L + 5e-12 < R; F(x1) < F(x2) ? R = x2 : L = x1)
		x1 = (L + L + R) / 3, x2 = (L + R + R) / 3;
	printf("%.8lf", F(L));
}