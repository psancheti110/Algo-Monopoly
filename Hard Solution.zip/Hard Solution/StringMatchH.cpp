/*
CodeForces 835D - Palindromic characteristics [Analysis, DP] | Codeforces Round # 427 (Div 2.)
 Meaning of the questions:
	 K is defined to meet the palindromic sequence:
		 Equal to about 1. substring
		 2. The left substring palindromic sequence k-1
	 1 palindrome string is a palindrome string
	 The number of each child asks you order palindrome substring of string s string
 Analysis:
	 Look can be found k palindrome string of requirements equivalent to
		 1. The string itself is palindromic
		 2 is a left substring palindromic sequence k-1
	 You can then dp, there is a conclusion:
		 If k is a palindromic sequence, then it must be palindromic k-1
	 Facilitate the final tally
*/
#include <bits/stdc++.h>
using namespace std;
const int N = 5005;
char s[N];
int len;
int dp[N][N], ans[N];
void init()
{
    int l;
    for (int i = 0; i < len; i++)
    {
        l = 0;
        while (i-l >= 0 && i+l < len && s[i-l] == s[i+l])
        {
            dp[i-l][i+l] = 1; ++ans[1];
            ++l;
        }
        l = 0;
        while (i-l >= 0 && i+l+1 < len && s[i-l] == s[i+l+1])
        {
            dp[i-l][i+l+1] = 1; ++ans[1];
            ++l;
        }
    }
}
void solve()
{
    for (int k = 2; k <= len; k++)
    {
        for (int i = 0; i < len; i++)
        {
            int j = i+k-1;
            int mid = i+k/2-1;
            if (dp[i][mid] && dp[i][j])
            {
                dp[i][j] = max(dp[i][j], dp[i][mid]+1);
                ans[dp[i][j]]++;
            }
        }
    }
}
int main()
{
    scanf("%s", s);
    len = strlen(s);
    init();
    solve();
    for (int i = len; i >= 2; i--)
        ans[i] += ans[i+1];
    for (int i = 1; i <= len; i++)
        printf("%d ", ans[i]);
    puts("");
}
