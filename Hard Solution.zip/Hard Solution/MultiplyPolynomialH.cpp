#include<bits/stdc++.h>
using namespace std;
const double pi=acos(-1);
vector<int>a[200005];
int n,m,k;
struct cp{
	double x,y;
}cur[400005];
cp operator + (cp a,cp b){
	return (cp){a.x+b.x,a.y+b.y};
}
cp operator - (cp a,cp b){
	return (cp){a.x-b.x,a.y-b.y};
}
cp operator * (cp a,cp b){
	return (cp){a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x};
}
vector<cp>aa,bb;
void fft(vector<cp> &a,int n,int fl){
	for(int i=(n>>1),j=1;j<n;j++){
		if(i<j)
			swap(a[i],a[j]);
		int k;
		for(k=(n>>1);k&i;i^=k,k>>=1);
		i^=k; 
	}
	for(int m=2;m<=n;m<<=1){
		cp w=(cp){cos(2*pi*fl/m),sin(2*pi*fl/m)};
		cur[0]=(cp){1,0};
		for(int j=1;j<(m>>1);j++)
			cur[j]=cur[j-1]*w;
		for(int i=0;i<n;i+=m)
			for(int j=i;j<i+(m>>1);j++){
				cp u=a[j],v=a[j+(m>>1)]*cur[j-i];
				a[j]=u+v;
				a[j+(m>>1)]=u-v;
			}
	}
	if(fl==-1)
		for(int i=0;i<n;i++)
			a[i]=(cp){a[i].x/n,a[i].y/n};
}
vector<int> multi(vector<int> A,vector<int> B){
	int lena=A.size(),lenb=B.size(),len=1;
	while(len<2*max(lena,lenb))
		len<<=1;
	aa=vector<cp>(len);
	bb=vector<cp>(len);
	for(int i=0;i<lena;i++)
		aa[i]=(cp){(double)A[i],0};
	for(int i=0;i<lenb;i++)
		bb[i]=(cp){(double)B[i],0};
	fft(aa,len,1);
	fft(bb,len,1);
	for(int i=0;i<len;i++)
		aa[i]=aa[i]*bb[i];
	fft(aa,len,-1);
	A.clear();
	for(int i=0;i<min(len,k+1);i++)
		A.push_back((long long)(aa[i].x+0.5)%1009);
	return A;
}
vector<int> work(int l,int r){
	if(l==r)
		return a[l];
	int mid=(l+r)>>1;
	return multi(work(l,mid),work(mid+1,r));
}
int main(){
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++)
		a[i].push_back(1);
	for(int i=1;i<=n;i++){
		int x;
		scanf("%d",&x);
		a[x].push_back(1);
	}
	printf("%d\n",work(1,m)[k]);
	return 0;
}
