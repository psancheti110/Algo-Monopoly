#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define sca(x) scanf("%d",&x)
#define pb(x) push_back(x)
#define mp(x,y) make_pair(x,y)
#define fir first
#define sec second
#define inf 0x3f3f3f3f

const int N = 2e5 + 5;
struct node
{
    int x, y, w, id;
    friend bool operator <(node a, node b)
    {
        return a.w < b.w;
    }
};

vector<node>V;
vector<pair<int, int> >G[N];

int f[N], used[N];

int Find(int x)
{
    return f[x] == x ? x : f[x] = Find(f[x]);
}

void make_tree(int n, int m)//First find any minimum spanning tree
{
    for (int i = 1; i <= n; i++)f[i] = i;
    sort(V.begin(), V.end());
    for (int i = 0; i < m; i++)
    {
        int f1 = Find(V[i].x);
        int f2 = Find(V[i].y);
        if (f1 != f2)
        {
            f[f1] = f2;
            G[V[i].x].pb(mp(V[i].y, V[i].w));
            G[V[i].y].pb(mp(V[i].x, V[i].w));
            used[i] = 1;
        }
    }
}

int b[N][20], a[N][20], c[N][20];
int ans[N], dep[N];

void dfs(int u, int fa)
{
    b[u][0] = fa;
    dep[u] = dep[fa] + 1;
    for (int i = 0; i < G[u].size(); i++)
    {
        int v = G[u][i].fir;
        int w = G[u][i].sec;
        if (v != fa)
        {
            a[v][0] = w; //overhead root node, convert edge weight to point weight
            dfs(v, u);
        }
    }
}

void pre_work(int n)
{
    for (int i = 1; i <= 18; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            b[j][i] = b[b[j][i - 1]][i - 1];
            a[j][i] = max(a[j][i - 1], a[b[j][i - 1]][i - 1]);
        }
    }
}

int query(int x, int y)
{
    int ans = 0;
    if (dep[x] < dep[y])swap(x, y);
    for (int i = 18; i >= 0; i--)
    {
        if (dep[b[x][i]] >= dep[y])
        {
            ans = max(ans, a[x][i]);
            x = b[x][i];
        }
    }
    if (x == y)return ans;
    for (int i = 18; i >= 0; i--)
    {
        if (b[x][i] != b[y][i])
        {
            ans = max(ans, max(a[x][i], a[y][i]));
            x = b[x][i];
            y = b[y][i];
        }
    }
    return max(ans, max(a[x][0], a[y][0]));
}

void upd(int x, int y, int val)
{
    if (dep[x] < dep[y])swap(x, y);
    for (int i = 18; i >= 0; i--)
    {
        if (dep[b[x][i]] >= dep[y])
        {
            c[x][i] = min(c[x][i], val);
            x = b[x][i];
        }
    }
    if (x == y)return ;
    for (int i = 18; i >= 0; i--)
    {
        if (b[x][i] != b[y][i])
        {
            c[x][i] = min(c[x][i], val);
            c[y][i] = min(c[y][i], val);
            x = b[x][i];
            y = b[y][i];
        }
    }
    c[x][0] = min(c[x][0], val); // Finally don't forget to update.
    c[y][0] = min(c[y][0], val);
}

int main()
{
    int n, m;
    sca(n), sca(m);
    for (int i = 1; i <= m; i++)
    {
        node tmp;
        scanf("%d%d%d", &tmp.x, &tmp.y, &tmp.w);
        tmp.id = i;
        V.pb(tmp);
    }
    make_tree(n, m);
    dfs(1, 0);
    pre_work(n);
    memset(c, inf, sizeof(c));
    for (int i = 0; i < m; i++)
    {
        if (!used[i])
        {
            ans[V[i].id] = query(V[i].x, V[i].y) - 1;
            upd(V[i].x, V[i].y, V[i].w);
        }
    }
    for (int i = 18; i >= 1; i--) // Due to the upd operation above, we only updated the large interval, and now we want to push down.
    {
        for (int j = 1; j <= n; j++)
        {
            c[j][i - 1] = min(c[j][i - 1], c[j][i]);
            c[b[j][i - 1]][i - 1] = min(c[b[j][i - 1]][i - 1], c[j][i]);
        }
    }
    for (int i = 0; i < m; i++)
    {
        if (used[i])
        {
            int x = V[i].x;
            int y = V[i].y;
            if (b[x][0] == y) ans[V[i].id] = c[x][0] - 1;
            else ans[V[i].id] = c[y][0] - 1;
        }
    }
    for (int i = 1; i <= m; i++)
    {
        if (ans[i] >= 1000000001)printf("-1 ");
        else printf("%d ", ans[i]);
    }
    printf("\n");
}
